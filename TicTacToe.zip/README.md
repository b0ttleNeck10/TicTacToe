# TicTacToe

#Instructions
1. download the zip file
2. unzip the the file
3. open the TicTacToe.sln
4. choose "Play with AI" or "Play with Friend"
5. play
